
  # Vietnamese Language Support

  This is a code bundle for Vietnamese Language Support. The original project is available at https://www.figma.com/design/lN8m3GSEK1XX2ti6TrAIdm/Vietnamese-Language-Support.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  